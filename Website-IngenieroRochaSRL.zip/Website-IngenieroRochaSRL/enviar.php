<?php
$name = $_POST['fullname'];
$mail = $_POST['Email'];
$phone = $_POST['Telefono'];
$affair = $_POST['Asunto'];
$message = $_POST['Mensaje'];

$header = 'From: ' . $mail . " \r\n";
$header .= "X-Mailer: PHP/" . phpversion() . " \r\n";
$header .= "Mime-Version: 1.0 \r\n";
$header .= "Content-Type: text/plain";

$message = "Este mensaje fue enviado por: " . $name . " \r\n";
$message .= "Su e-mail es: " . $mail . " \r\n";
$message .= "Teléfono de contacto: " . $phone . " \r\n";

$message .= "Mensaje: " . $_POST['message'] . " \r\n";
$message .= "Asunto es: " . $affair . " \r\n";
$message .= "Mensaje: " . $_POST['message'] . " \r\n";
$para = 'guidolucianorocha@gmail.com';
$asunto = 'Nuevo mensaje web';

mail($para, $asunto, utf8_decode($message), $header);

header "D:/Website-IngenieroRochaSRL/index.html";
?>